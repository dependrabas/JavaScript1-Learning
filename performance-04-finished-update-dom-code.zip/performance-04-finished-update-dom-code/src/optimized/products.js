export const products = [
  {
    id: new Date('1/1/1970').toString(),
    title: 'A Book',
    price: 12.99
  },
  {
    id: new Date('1/2/1970').toString(),
    title: 'A Carpet',
    price: 129.99
  },
  {
    id: new Date('1/3/1970').toString(),
    title: 'A Magic Broomstick',
    price: 599.99
  },
  {
    id: new Date('1/4/1970').toString(),
    title: 'A Bottle',
    price: 2.99
  },
  {
    id: new Date('1/5/1970').toString(),
    title: 'A T-Shirt',
    price: 29.99
  }
];