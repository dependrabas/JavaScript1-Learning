const button = document.querySelector('button');

button.addEventListener('click', () => {
  // do something...
});